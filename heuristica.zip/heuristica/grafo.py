
class Vertice():
    def __init__(self,string):
        self.nome = string
        self.arestas = list()
    def getGrau(self):
        return len(self.arestas)
    def addAresta(self):
        pass
    def getNome(self):
        return self.nome
    def getArestas():
        return self.arestas
    def addArestas(aresta):
        self.arestas.append(aresta)
    def setArestas(self,list_aresta):
        self.arestas = list_aresta
    def __str__(self):
        return self.getNome()

class Aresta():
    def __init__(self,string):
        string = string.replace('{','')
        string = string.replace('}','')
        conf = string.split(',')
        self.string_vertice = [conf[0],conf[1]]
        self.peso = int(conf[2])
        self.direcao = int(conf[3])
        self.vertices = None
    def getPeso(self):
        return self.peso
    def setPeso(self,novo_peso):
        self.peso = novo_peso
    def get_string_vertice(self):
        return self.string_vertice
    def setVertices(self,v1,v2):
        #print(v1,v2)
        self.vertices = [v1,v2]
    def getVertices(self,):
        return self.vertices

        
class Grafo():
    def __init__(self):
        self.vertices = list()
        self.arestas = list()
    def add_vertice(self,string):
        string = string.replace('[','')
        string = string.replace(']','')
        conf = string.split(',')
        for i in conf:
            self.vertices.append(Vertice(i))
    def add_aresta(self,string):
        self.arestas.append(Aresta(string))
    def findVertice(self,string):
        for i in self.vertices:
            if i.getNome() == string:
                return i
        return None
    def findAresta(self,string):
        retorno = list()
        for i in self.arestas:
            v = i.getVertices()
            if v[0].getNome() == string or v[1].getNome() == string:
                retorno.append(i)
        return retorno
    def linker_aresta_vertice(self):
        for i in self.arestas:
            v = i.get_string_vertice()
            i.setVertices(self.findVertice(v[0]),self.findVertice(v[1]))
    def linker_vertice_aresta(self):
        for i in self.vertices:
            list_arestas = self.findAresta(i.getNome())
            i.setArestas(list_arestas)
    def getVertices(self):
        return self.vertices
    def getArestas(self):
        return self.arestas
            
            
        
list_grafos = []
inp = open('input.txt','r')
for i in inp:
    c = Grafo()
    v = i.split(';')
    c.add_vertice(v[0])
    for j in v:
        if j[0] == '{':
            c.add_aresta(j)
    c.linker_aresta_vertice()
    c.linker_vertice_aresta()
    list_grafos.append(c)
    

            
